using System.Windows.Controls;

namespace WPAppStudio.Controls
{
    public class AppBarMenuItem : HyperlinkButton
    {
        public AppBarMenuItem()
        {
            DefaultStyleKey = typeof(AppBarMenuItem);
        }
    }
}
